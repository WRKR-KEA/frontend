// app/administer/categorymanagement/page.tsx
import ClientPage from './client-page';

export default function Page() {
  return <ClientPage />;
}