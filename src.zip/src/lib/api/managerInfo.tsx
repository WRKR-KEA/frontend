import axios from 'axios';

const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL;

//담당자 마이페이지 조회 API

//담당자 마이페이지 수정 API